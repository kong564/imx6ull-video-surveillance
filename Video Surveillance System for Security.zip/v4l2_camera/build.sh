#!/bin/sh

make clean

qmake
make -j4

if cp v4l2_camera /mnt/hgfs/Public; then
	echo "app部署成功"
fi
