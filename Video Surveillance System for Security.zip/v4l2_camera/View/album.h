#ifndef ALBUM_H
#define ALBUM_H

#include <QWidget>
#include <QImage>
#include <QDebug>
#include <QLabel>
#include "config.h"

namespace Ui {
class Album;
}

class Album : public QWidget
{
    Q_OBJECT

public:
    explicit Album(QWidget *parent = nullptr);
    ~Album();

private:
     void buildConnect();

signals:
     void AlbumMessage(AlbumSignal message);

public slots:
     void handlePhoto(const QString& photo);
     void handleNumLab(int index, int size);

private:
    Ui::Album *ui;
};

#endif // ALBUM_H
