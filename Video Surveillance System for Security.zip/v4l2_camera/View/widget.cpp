#include "widget.h"
#include "viewmodel.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);


    buildConnect();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::setUpSlider(WidgetSiganl object, int min, int max, int def, int step)
{
    switch (object) {
        case SLIDER_BRIGHTNESS:
           if(ui->slider_bri)
           {
               ui->slider_bri->setRange(min, max);
               ui->slider_bri->setValue(def);
               ui->slider_bri->setSingleStep(step);
               ui->slider_bri->setPageStep(5 * step);
           }
            break;
        case SLIDER_CONTRAST:
            if(ui->slider_con)
            {
                ui->slider_con->setRange(min, max);
                ui->slider_con->setValue(def);
                ui->slider_con->setSingleStep(step);
                ui->slider_con->setPageStep(5 * step);
            }
            break;
        case SLIDER_GAMMA:
            if(ui->slider_gamma)
            {
                ui->slider_gamma->setRange(min, max);
                ui->slider_gamma->setValue(def);
                ui->slider_gamma->setSingleStep(step);
                ui->slider_gamma->setPageStep(5 * step);
            }
            break;
        case SLIDER_SATURATION:
            if(ui->slider_sat)
            {
                ui->slider_sat->setRange(min, max);
                ui->slider_sat->setValue(def);
                ui->slider_sat->setSingleStep(step);
                ui->slider_sat->setPageStep(5 * step);
            }
            break;
        case SLIDER_FPS:  // 照葫芦画瓢添加FPS
               if(ui->slider_fps)
               {
                   ui->slider_fps->setRange(min, max);
                   ui->slider_fps->setValue(def);
                   ui->slider_fps->setSingleStep(step);
                   ui->slider_fps->setPageStep(5 * step);
               }
               break;
        case SLIDER_PIXEL:  // 照葫芦画瓢添加PIXEL
           if(ui->slider_pixel)
           {
               ui->slider_pixel->setRange(min, max);
               ui->slider_pixel->setValue(def);
               ui->slider_pixel->setSingleStep(step);
               ui->slider_pixel->setPageStep(5 * step);
           }
           break;
        default:
            qDebug() << "Unknown slider:" << object;
            break;
    }
}

void Widget::buildConnect()
{
    // 按钮名称与信号的映射
    QVector<QPair<QString, WidgetSiganl>> buttonSignals = {
        {"btn_take", TAKEPHOTO},
        {"btn_exit", EXIT},
        {"btn_filter", FILTER},
        {"btn_album", ALBUM},
        {"btn_stop", STOP},
        {"btn_video", VIDEO}
    };

    // 使用 for 循环连接所有按钮
    for (const auto& pair : buttonSignals) {
        QPushButton* button = findChild<QPushButton*>(pair.first);
        if (button) {
            connect(button, &QPushButton::clicked, this, [=]() {
                emit ButtonMessage(pair.second);  // 发射对应的信号
            });
        }
        else
        {
            qDebug() << pair.first;
        }
    }

    QVector<QPair<QString, WidgetSiganl>> sliderSignals = {
        {"slider_bri", SLIDER_BRIGHTNESS},
        {"slider_con", SLIDER_CONTRAST},
        {"slider_gamma", SLIDER_GAMMA},
        {"slider_sat", SLIDER_SATURATION},
        {"slider_fps", SLIDER_FPS},
        {"slider_pixel",SLIDER_PIXEL}
    };

    // 使用 for 循环连接所有 Slider
    for (const auto& pair : sliderSignals) {
        QSlider* slider = findChild<QSlider*>(pair.first);
        if (slider) {
            connect(slider, &QSlider::valueChanged, this, [=](int value) {
                emit SliderMessage(pair.second, value);  // 发射Slider信号，传递值
            });
        }
        else
        {
            qDebug() << "未找到 Slider:" << pair.first;
        }
    }

}

void Widget::handlePhoto(QImage photo)
{
    if (photo.isNull()) {
        qDebug() << "Invalid photo received";
        return;
    }
    QPixmap pixmap = QPixmap::fromImage(photo);
    ui->photo->setPixmap(pixmap);
}

void Widget::handleUpdate(ViewModelSignal message)
{
    switch (message)
    {
        case HIDEPHOTO:
        ui->photo->hide();
        QTimer::singleShot(150, this, [this]() {
            ui->photo->show();
        });
        break;

    }
}

void Widget::handleLabel(WidgetSiganl message, const QString &str)
{
    switch (message)
    {
        case LABEL_BRIGHTNESS:
            if(ui->birght_lab) {
                ui->birght_lab->setText(str);
            }
            break;
        case LABEL_CONTRAST:
            if(ui->contrast_lab) {
                ui->contrast_lab->setText(str);
            }
            break;
        case LABEL_GAMMA:
            if(ui->gamma_lab) {
                ui->gamma_lab->setText(str);
            }
            break;
        case LABEL_SATURATION:
            if(ui->saturation_lab) {
                ui->saturation_lab->setText(str);
            }
            break;
        case LABEL_FPS:  // 照葫芦画瓢添加FPS
                    if(ui->fps_lab) {
                        ui->fps_lab->setText(str);
                    }
            break;
        case LABEL_PIXEL:  // 照葫芦画瓢添加PIXEL
            if(ui->pixel_lab) {
                ui->pixel_lab->setText(str);
            }
            break;
        case LABEL_CAMERA_STATUS:  // 照葫芦画瓢添加CAMERA_STATUS
            if(ui->camera_status_lab) {
                ui->camera_status_lab->setText(str);
            }
            break;
        case LABEL_NETWORK_STATUS:  // 照葫芦画瓢添加NETWORK_STATUS
            if(ui->network_status_lab) {
                ui->network_status_lab->setText(str);
            }
            break;
        default:
            qDebug() << "Unknown label message:" << message;
            break;
    }
}

void Widget::ChangeBtn(ChangeWidgetBtn message, bool status)
{
    QString style;

    switch (message) {
        case BTN_STOP:
        if(status == false)
        {
            ui->btn_stop->setText("start");
            style = "background-color: rgb(87, 227, 137);" + QString("border-radius: 15px;");
            ui->btn_stop->setStyleSheet(style);

        }
        else
        {
            ui->btn_stop->setText("stop");
            style = "background-color: rgb(237, 51, 59);" + QString("border-radius: 15px;");
            ui->btn_stop->setStyleSheet(style);
        }
        break;

        case BTN_VIDEO:
        break;

    }
}

