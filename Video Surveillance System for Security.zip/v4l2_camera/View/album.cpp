#include "album.h"
#include "ui_album.h"

Album::Album(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Album)
{
    ui->setupUi(this);
    buildConnect();
}

Album::~Album()
{
    delete ui;
}

void Album::buildConnect()
{
    QVector<QPair<QString, AlbumSignal>> buttonSignals = {
        {"btn_exit", ALBUM_EXIT},
        {"btn_left", ALBUM_LEFT},
        {"btn_right", ALBUM_RIGHT},
        {"btn_delete",ALBUM_DELETE}
    };

    // 使用 for 循环连接所有按钮
    for (const auto& pair : buttonSignals) {
        QPushButton* button = findChild<QPushButton*>(pair.first);
        if (button) {
            connect(button, &QPushButton::clicked, this, [=]() {
                emit AlbumMessage(pair.second);  // 发射对应的信号
            });
        }
        else
        {
            qDebug() << pair.first;
        }
    }
}

void Album::handlePhoto(const QString &photo)
{
    if (photo.isEmpty()) {
           ui->photo_lab->setText("not exist photo");
           return;
       }

       QPixmap pixmap(photo);
       if (pixmap.isNull()) {
           ui->photo_lab->setText("load photo failed");
           return;
       }

       ui->photo_lab->setPixmap(pixmap);
}

void Album::handleNumLab(int index, int size)
{
    QString display = QString::number(index + 1) + "/" + QString::number(size);
    ui->num_lab->setText(display);
}
