#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QImage>
#include <QDebug>
#include <QLabel>
#include "config.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void setUpSlider(WidgetSiganl object, int min, int max, int def, int step);

private:
    void buildConnect();

signals:
    void ButtonMessage(WidgetSiganl message);
    void SliderMessage(WidgetSiganl message, int value);

public slots:
    void handlePhoto(QImage photo);
    void handleUpdate(ViewModelSignal message);
    void handleLabel(WidgetSiganl message, const QString& str);
    void ChangeBtn(ChangeWidgetBtn message, bool status);


private:
    Ui::Widget *ui;
};
#endif // WIDGET_H
