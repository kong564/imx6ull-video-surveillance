#include "albummanager.h"
#include <QDebug>
#include "config.h"
AlbumManager::AlbumManager(QObject *parent) : QObject(parent)
{

}

bool AlbumManager::setPhotosPath(const QString &path)
{
    QDir dir(path);
    if(dir.isEmpty())
    {
        qDebug() << "path not exist " << path;
        return false;
    }

    m_basePath = path;

    QStringList filters {"*.jpg"};
    m_photosPath = dir.entryList(filters, QDir::Files);
    if(m_photosPath.isEmpty())
    {
         qDebug() << "photo not exist";
        return false;
    }

    m_index = 0;
    return true;
}

void AlbumManager::upDatePhoto()
{
    QDir dir(m_basePath);
    if(dir.isEmpty())
    {
        qDebug() << "path not exist update photo failed";
    }
    if(m_index == -1 && m_photosPath.isEmpty())
    {
        //重置为有照片状态
        m_index = 0;
    }
    QStringList filters {"*.jpg"};
    m_photosPath = dir.entryList(filters, QDir::Files);
}

QString AlbumManager::getCurrentPhoto() const
{
    if(m_index < 0)
    {
        return QString();
    }
    return m_basePath + m_photosPath.at(m_index);
}

int AlbumManager::getIndex() const
{
    return m_index;
}

int AlbumManager::getAlbumNum() const
{
    return  m_photosPath.size();
}

bool AlbumManager::deleteCurrentPhoto()
{
    if (m_photosPath.isEmpty() || m_index < 0 || m_index >= m_photosPath.size()) {
         qDebug() << "delete photo falid because album empty";
        return false;
    }

    QString filePath = PHOTO_DIR + m_photosPath.at(m_index);
     qDebug() << "filePath:" << filePath;
    // 从列表移除
    m_photosPath.removeAt(m_index);

    QFile file(filePath);
    bool fileRemoved = file.remove();

    qDebug() << "delete result:" << fileRemoved;

    if (!fileRemoved) {
        qDebug() << "error code:" << file.error();
        qDebug() << "error string:" << file.errorString();
    }
    // 更新索引
    if (m_photosPath.isEmpty()) {
        m_index = -1;  // 没有照片了
    } else if (m_index >= m_photosPath.size()) {
        m_index = m_photosPath.size() - 1;  // 指向最后一张
    }

    return fileRemoved;
}

void AlbumManager::nextPhoto()
{
    if(m_index < m_photosPath.size() - 1 && m_index >= 0)
    {
        m_index++;
    }
}

void AlbumManager::lastPhoto()
{
    if(m_index > 0)
    {
        m_index--;
    }
}
