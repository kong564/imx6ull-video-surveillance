#ifndef CONFIG_H
#define CONFIG_H
#include <stdint.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>

#define PHOTO_DIR "./photos/"

enum CameraSignal
{
    DATATREADY = 1
};

enum WidgetSiganl
{
    TAKEPHOTO = 1,
    EXIT,
    FILTER,
    ALBUM,
    STOP,
    VIDEO,

    SLIDER_BRIGHTNESS,
    SLIDER_SATURATION,
    SLIDER_CONTRAST,
    SLIDER_GAMMA,
    SLIDER_FPS,
    SLIDER_PIXEL,

    LABEL_BRIGHTNESS,
    LABEL_SATURATION,
    LABEL_CONTRAST,
    LABEL_GAMMA,
    LABEL_FPS,
    LABEL_PIXEL,
    LABEL_CAMERA_STATUS,
    LABEL_NETWORK_STATUS
};

enum ChangeWidgetBtn
{
    BTN_STOP = 1,
    BTN_VIDEO
};

enum AlbumSignal
{
    ALBUM_EXIT = 1,
    ALBUM_LEFT,
    ALBUM_RIGHT,
    ALBUM_DELETE
};

enum ViewModelSignal
{
    HIDEPHOTO = 1,
};

// 亮度调节 (-255 到 255)
#define BRIGHTNESS_MIN      -255
#define BRIGHTNESS_MAX      255
#define BRIGHTNESS_DEFAULT  0
#define BRIGHTNESS_STEP     5        // 步进值5，共102个档位

// 对比度调节 (0 到 30)
#define CONTRAST_MIN        0
#define CONTRAST_MAX        30
#define CONTRAST_DEFAULT    15
#define CONTRAST_STEP       1        // 步进值1，共31个档位

// 饱和度调节 (0 到 127)
#define SATURATION_MIN      0
#define SATURATION_MAX      127
#define SATURATION_DEFAULT  30
#define SATURATION_STEP     2        // 步进值2，共64个档位

// Gamma调节 (20 到 250)
#define GAMMA_MIN          20
#define GAMMA_MAX          250
#define GAMMA_DEFAULT      98
#define GAMMA_STEP         5        // 步进值5，共47个档位

// Gamma调节 (20 到 250)
#define GAMMA_MIN          20
#define GAMMA_MAX          250
#define GAMMA_DEFAULT      98
#define GAMMA_STEP         5        // 步进值5，共47个档位

// Pixel调节 (最小到最大)
#define PIXEL_MIN          1        // 通常像素值从1开始
#define PIXEL_MAX          16       // 或者根据实际需求，比如16倍像素
#define PIXEL_DEFAULT      1        // 默认1倍像素
#define PIXEL_STEP         1        // 步进值1，整数倍变化

// FPS调节
#define FPS_MIN            10        // 最小1帧
#define FPS_MAX            60       // 最大30帧（或根据相机能力调整）
#define FPS_DEFAULT        20       // 默认15帧
#define FPS_STEP           1        // 步进值1帧

#define NOT_EXIST_PHOTO -2

#endif // CONFIG_H
