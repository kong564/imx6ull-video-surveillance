#ifndef ALBUMMANAGER_H
#define ALBUMMANAGER_H

#include <QObject>
#include <QDir>
#include <QStringList>

class AlbumManager : public QObject
{
    Q_OBJECT
public:
    explicit AlbumManager(QObject *parent = nullptr);
    bool setPhotosPath(const QString& path);
    void upDatePhoto();

    QString getCurrentPhoto() const;
    int getIndex() const;
    int getAlbumNum() const;
    bool deleteCurrentPhoto();

    void nextPhoto();
    void lastPhoto();

private:
    QStringList m_photosPath;
    QString m_basePath;
    int m_index = -1;
};

#endif // ALBUMMANAGER_H
