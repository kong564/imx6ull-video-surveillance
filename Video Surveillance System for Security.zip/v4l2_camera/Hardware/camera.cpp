#include "camera.h"
#include <QDebug>
#include "config.h"
#include <cstring>
#include <QDir>
Camera::Camera(int width, int height, uint32_t pixelformat, QObject *parent)
    : QObject(parent)
    , m_width(width)
    , m_height(height)
    , m_pixelFormat(pixelformat)
{
    m_bufferCount = 4;

    // 打开设备
    m_fd = open("/dev/video1", O_RDWR);
    if (m_fd < 0) {
        qDebug() << "Device open failed";
        return;
    }

    // 设置格式
    struct v4l2_format fmt;
    memset(&fmt, 0, sizeof(fmt));
    fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    fmt.fmt.pix.pixelformat = m_pixelFormat;
    fmt.fmt.pix.width = m_width;
    fmt.fmt.pix.height = m_height;
    fmt.fmt.pix.field = V4L2_FIELD_ANY;

    if (ioctl(m_fd, VIDIOC_S_FMT, &fmt) < 0) {
        qDebug() << "Format set failed";
        close(m_fd);
        m_fd = -1;
        return;
    }

    // 申请缓冲区
    struct v4l2_requestbuffers reqbuf;
    memset(&reqbuf, 0, sizeof(reqbuf));
    reqbuf.count = m_bufferCount;
    reqbuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    reqbuf.memory = V4L2_MEMORY_MMAP;

    if (ioctl(m_fd, VIDIOC_REQBUFS, &reqbuf) < 0) {
        qDebug() << "Buffer request failed";
        close(m_fd);
        m_fd = -1;
        return;
    }

    m_bufferCount = reqbuf.count;
    m_buffers = new Buffer[m_bufferCount];

    // 映射缓冲区
    for (int i = 0; i < m_bufferCount; i++) {
        struct v4l2_buffer buf;
        memset(&buf, 0, sizeof(buf));
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.index = i;
        buf.memory = V4L2_MEMORY_MMAP;

        if (ioctl(m_fd, VIDIOC_QUERYBUF, &buf) < 0) {
            qDebug() << "Buffer query failed";
            goto error;
        }

        m_buffers[i].length = buf.length;
        m_buffers[i].start = mmap(NULL, buf.length, PROT_READ | PROT_WRITE,
                                 MAP_SHARED, m_fd, buf.m.offset);

        if (m_buffers[i].start == MAP_FAILED) {
            qDebug() << "Memory map failed";
            goto error;
        }
    }

    // 缓冲区入队
    for (int i = 0; i < m_bufferCount; i++) {
        struct v4l2_buffer buf;
        memset(&buf, 0, sizeof(buf));
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.index = i;
        buf.memory = V4L2_MEMORY_MMAP;

        if (ioctl(m_fd, VIDIOC_QBUF, &buf) < 0) {
            qDebug() << "Buffer enqueue failed";
            goto error;
        }
    }

    m_initialized = true;
    qDebug() << "Camera initialized:" << m_width << "x" << m_height;
    return;

error:
    for (int i = 0; i < m_bufferCount; i++) {
        if (m_buffers && m_buffers[i].start != MAP_FAILED) {
            munmap(m_buffers[i].start, m_buffers[i].length);
        }
    }
    delete[] m_buffers;
    m_buffers = nullptr;

    if (m_fd >= 0) {
        close(m_fd);
        m_fd = -1;
    }
}

Camera::~Camera()
{
    if (m_isStream) {
        stopCapture();
    }

    if (m_buffers) {
        for (int i = 0; i < m_bufferCount; i++) {
            if (m_buffers[i].start != MAP_FAILED) {
                munmap(m_buffers[i].start, m_buffers[i].length);
            }
        }
        delete[] m_buffers;
        m_buffers = nullptr;
    }

    if (m_fd >= 0) {
        close(m_fd);
        m_fd = -1;
    }

    qDebug() << "Camera released";
}

bool Camera::startCapture()
{
    if (!m_initialized) {
        qDebug() << "Camera not initialized";
        return false;
    }

    enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(m_fd, VIDIOC_STREAMON, &type) < 0) {
        qDebug() << "Camera start failed";
        return false;
    }

    m_isStream = true;
    qDebug() << "Camera capture started";
    return true;
}

bool Camera::stopCapture()
{
    if (!m_initialized || !m_isStream) {
        return false;
    }

    enum v4l2_buf_type type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(m_fd, VIDIOC_STREAMOFF, &type) < 0) {
        qDebug() << "Camera stop failed";
        return false;
    }

    m_isStream = false;
    qDebug() << "Camera capture stopped";
    return true;
}

bool Camera::getFrame()
{
    if (!m_initialized || !m_isStream) {
        qDebug() << "Camera not ready";
        return false;
    }

    struct v4l2_buffer buf;
    memset(&buf, 0, sizeof(buf));
    buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    buf.memory = V4L2_MEMORY_MMAP;

    if (ioctl(m_fd, VIDIOC_DQBUF, &buf) < 0) {
        qDebug() << "Data acquisition failed";
        return false;
    }

    // 关键：先调整缓冲区大小，再复制数据
    if (m_frameData.size() < buf.bytesused) {
        m_frameData.resize(buf.bytesused);
    }

    // 复制数据到安全缓冲区
    memcpy(m_frameData.data(), m_buffers[buf.index].start, buf.bytesused);
    m_byteUsed = buf.bytesused;

    // 立即归还缓冲区
    if (ioctl(m_fd, VIDIOC_QBUF, &buf) < 0) {
        qDebug() << "Buffer re-enqueue failed";
        return false;
    }

    // 创建 QImage
    m_currentImage = QImage::fromData(
        reinterpret_cast<const uchar*>(m_frameData.constData()),
        m_byteUsed,
        "JPEG"
    );

    emit CameraMessage(DATATREADY);
    return true;
}

QImage Camera::getImage()
{
    return m_currentImage;
}

bool Camera::capturePhoto(const QString& filename, const QString& direct)
{
    if (!m_initialized || !m_isStream) {
        qDebug() << "Camera not ready";
        return false;
    }

    QDir dir(direct);
    QString file;
    if (dir.exists() && !filename.isEmpty())
    {
       file = direct + filename;
    }
    else
    {
        qDebug() << "file is empty or direct is not exist";
        return false;
    }

    struct v4l2_buffer buf;
    memset(&buf, 0, sizeof(buf));
    buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    buf.memory = V4L2_MEMORY_MMAP;

    if (ioctl(m_fd, VIDIOC_DQBUF, &buf) < 0) {
        qDebug() << "Data acquisition failed";
        return false;
    }

    FILE* fp = fopen(file.toLocal8Bit().constData(), "wb");
    if (!fp) {
        ioctl(m_fd, VIDIOC_QBUF, &buf);
        qDebug() << "File creation failed";
        return false;
    }

    fwrite(m_buffers[buf.index].start, 1, buf.bytesused, fp);
    fclose(fp);

    qDebug() << "Photo saved:" << filename << "Size:" << buf.bytesused << "bytes";

    if (ioctl(m_fd, VIDIOC_QBUF, &buf) < 0) {
        qDebug() << "Buffer re-enqueue failed";
        return false;
    }
    return true;
}

bool Camera::setImageControl(int control_id, int value)
{
    if(!checkControlValue(control_id, value) || !m_initialized)
    {
        return false;
    }

    struct v4l2_control ctl;
    memset(&ctl, 0, sizeof(ctl));
    ctl.id = control_id;
    ctl.value = value;

    if(ioctl(m_fd, VIDIOC_S_CTRL, &ctl) < 0)
    {
        qDebug() << "ImageControl set failed " << control_id;
        return false;
    }
    return true;
}

bool Camera::setBrightness(int value)
{
    return setImageControl(V4L2_CID_BRIGHTNESS, value);
}

bool Camera::setSharpness(int value)
{
    return setImageControl(V4L2_CID_SHARPNESS, value);
}

bool Camera::setSaturation(int value)
{
    return setImageControl(V4L2_CID_SATURATION, value);
}

bool Camera::setGamma(int value)
{
    return setImageControl(V4L2_CID_GAMMA, value);
}

bool Camera::setContrast(int value)
{
    return setImageControl(V4L2_CID_CONTRAST, value);
}

bool Camera::checkControlValue(int control_id, int value)
{
    if (!m_initialized) {
        qDebug() << "Camera not initialized";
        return false;
    }

    struct v4l2_queryctrl query;
    memset(&query, 0, sizeof(query));
    query.id = control_id;

    if(ioctl(m_fd, VIDIOC_QUERYCTRL, &query) == 0)
    {
        if(value >= query.minimum && value <= query.maximum)
        {
            return true;
        }
        else
        {
            qDebug() << "Value out of range:" << value
                             << "Valid range: [" << query.minimum
                             << "-" << query.maximum << "]";
            return false;
        }
    }
    qDebug() << "VIDIOC_QUERYCTRL failed";
    return false;
}

int Camera::getControlValue(int control_id)
{
    if (!m_initialized) {
        qDebug() << "Camera not initialized";
        return -1;
    }

    struct v4l2_control ctl;
    memset(&ctl, 0, sizeof(ctl));
    ctl.id = control_id;

    if(ioctl(m_fd, VIDIOC_G_CTRL, &ctl) == 0)
    {
        return ctl.value;
    }

    qDebug() << "Get control value failed. ID:" << control_id
                << "Error:" << strerror(errno);
    return -1;
}

const uint8_t* Camera::getFrameData() const
{
    if (!m_initialized || m_index < 0 || m_index >= m_bufferCount) {
        return nullptr;
    }
    return static_cast<uint8_t*>(m_buffers[m_index].start);
}

void Camera::queryFormat()
{
        int i = 0;
        int j = 0;
        struct v4l2_fmtdesc fmtdesc;
        struct v4l2_frmsizeenum fsenum;

        fmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        fmtdesc.index = i;

        while(ioctl(m_fd, VIDIOC_ENUM_FMT, &fmtdesc) == 0)
        {
            printf("[%d] %s\n", i, fmtdesc.description);
            printf("    FourCC: %c%c%c%c\n",
                   (fmtdesc.pixelformat) & 0xFF,
                   (fmtdesc.pixelformat >> 8) & 0xFF,
                   (fmtdesc.pixelformat >> 16) & 0xFF,
                   (fmtdesc.pixelformat >> 24) & 0xFF);

            // 重置内层循环变量
            j = 0;
            memset(&fsenum, 0, sizeof(fsenum));
            fsenum.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            fsenum.index = j;
            fsenum.pixel_format = fmtdesc.pixelformat;  // 关键：设置像素格式

            while(ioctl(m_fd, VIDIOC_ENUM_FRAMESIZES, &fsenum) == 0)
            {
                if (fsenum.type == V4L2_FRMSIZE_TYPE_DISCRETE) {
                    printf("    framesize [%d]: %d x %d\n", j,
                           fsenum.discrete.width, fsenum.discrete.height);
                } else if (fsenum.type == V4L2_FRMSIZE_TYPE_STEPWISE) {
                    printf("    framesize [%d]: stepwise %dx%d to %dx%d, step %dx%d\n", j,
                           fsenum.stepwise.min_width, fsenum.stepwise.min_height,
                           fsenum.stepwise.max_width, fsenum.stepwise.max_height,
                           fsenum.stepwise.step_width, fsenum.stepwise.step_height);
                } else if (fsenum.type == V4L2_FRMSIZE_TYPE_CONTINUOUS) {
                    printf("    framesize [%d]: continuous %dx%d to %dx%d\n", j,
                           fsenum.stepwise.min_width, fsenum.stepwise.min_height,
                           fsenum.stepwise.max_width, fsenum.stepwise.max_height);
                }

                j++;
                fsenum.index = j;
            }

            i++;
            fmtdesc.index = i;
        }
}

void Camera::queryCapability()
{
    struct v4l2_capability cap;
    memset(&cap, 0, sizeof(cap));
    ioctl(m_fd, VIDIOC_QUERYCAP, &cap);
    qDebug() << cap.driver;
    qDebug() << cap.card;
    qDebug() << cap.bus_info;

    if(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)
    {
        qDebug() << "Device does not have capture capability";
        return;
    }
    qDebug() << "Device has capture capability";
}


