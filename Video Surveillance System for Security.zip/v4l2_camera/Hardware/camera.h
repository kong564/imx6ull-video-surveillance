#ifndef CAMERA_H
#define CAMERA_H

#include <QObject>
#include <QString>
#include <QImage>
#include "config.h"
extern "C" {
#include <stdint.h>
#include <stdbool.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
}

class Camera : public QObject
{
    Q_OBJECT
private:
    bool setImageControl(int control_id, int value);
    bool checkControlValue(int control_id, int value);


public:
    explicit Camera(int width = 640, int height = 480, uint32_t pixelformat = V4L2_PIX_FMT_MJPEG, QObject *parent = nullptr);
    ~Camera();

    bool startCapture();
    bool stopCapture();

    bool setBrightness(int value);
    bool setSharpness(int value);
    bool setSaturation(int value);
    bool setGamma(int value);
    bool setContrast(int value);
    int getControlValue(int control_id);

    bool getFrame();
    bool capturePhoto(const QString& filename, const QString& direct);
    QImage getImage();

    void queryCapability();
    void queryFormat();

    bool isStreaming() const { return m_isStream; }
    bool isInitialized() const { return m_initialized; }
    int currentWidth() const { return m_width; }
    int currentHeight() const { return m_height; }
    int currentBufferIndex() const { return m_index; }
    int currentDataSize() const { return m_byteUsed; }

    const uint8_t* getFrameData() const;

signals:
    void CameraMessage(CameraSignal signal);

private:
    struct Buffer {
        void* start;
        size_t length;
    };

    int m_fd = -1;
    int m_width = 0;
    int m_height = 0;
    int m_byteUsed = 0;
    int m_index = 0;
    int m_bufferCount = 0;
    uint32_t m_pixelFormat = V4L2_PIX_FMT_MJPEG;
    bool m_isStream = false;
    bool m_initialized = false;
    Buffer* m_buffers = nullptr;
    QImage m_currentImage = QImage();
    QByteArray m_frameData;
};

#endif // CAMERA_H
