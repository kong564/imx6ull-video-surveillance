#include "widget.h"
#include "album.h"
#include "camera.h"
#include "viewmodel.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    Album al;
    Camera c;

    ViewModel vw(&c, &w, &al);

    al.hide();
    w.show();
    return a.exec();
}
