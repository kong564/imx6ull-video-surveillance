#include "viewmodel.h"
#include <QDebug>
#include <QApplication>
#include <QDateTime>

ViewModel::ViewModel(Camera* camera, Widget* widget, Album* album, QObject *parent)
    : QObject(parent)
    , m_camera(camera)
    , m_widget(widget)
    , m_album(album)
{
    m_fpsTimer = new QTimer(this);
    m_albManager = new AlbumManager(this);
    m_albManager->setPhotosPath(PHOTO_DIR);


    buildConnect();
    setUpWidget();


    m_camera->startCapture();

    m_fps = 20;
    setFps(m_fps);
}

void ViewModel::buildConnect()
{
    connect(m_camera, &Camera::CameraMessage, this, &ViewModel::handleCameraSignals);
    connect(m_widget, &Widget::ButtonMessage, this, &ViewModel::handleWidgetButtonSignals);
    connect(m_album, &Album::AlbumMessage, this, &ViewModel::handleAlbumSignals);
    connect(m_widget, &Widget::SliderMessage, this, &ViewModel::handleWidgetSliderSignals);
    connect(m_fpsTimer, &QTimer::timeout, this, &ViewModel::handleFpsTimer);


    connect(this, &ViewModel::updatePhoto, m_widget, &Widget::handlePhoto);
    connect(this, &ViewModel::updateUI, m_widget, &Widget::handleUpdate);
    connect(this, &ViewModel::updataAlbum, m_album, &Album::handlePhoto);
    connect(this, &ViewModel::updataAlbumNumLab, m_album, &Album::handleNumLab);
    connect(this, &ViewModel::updataWidgetLab, m_widget, &Widget::handleLabel);
    connect(this, &ViewModel::changeWidgetBtn, m_widget, &Widget::ChangeBtn);
}

void ViewModel::setFps(int fps)
{
    if(fps < 10)
    {
       fps = 10;
    }
    if(fps > 60)
    {
        fps = 60;
    }
    m_fps = fps;

    m_fpsTimer->start(1000 / fps);
    m_isGetFrame = true;
}

QString ViewModel::generateTimestampFilename(const QString &prefix, const QString &extension)
{
    QDateTime now = QDateTime::currentDateTime();

    // 格式: photo_20231215_143025.jpg
    QString filename = QString("%1_%2.%3")
        .arg(prefix)
        .arg(now.toString("yyyyMMdd_hhmmss"))
        .arg(extension);

    return filename;
}

void ViewModel::setUpWidget()
{
    m_widget->setUpSlider(SLIDER_BRIGHTNESS, BRIGHTNESS_MIN, BRIGHTNESS_MAX, BRIGHTNESS_DEFAULT, BRIGHTNESS_STEP);
    m_widget->setUpSlider(SLIDER_SATURATION, SATURATION_MIN, SATURATION_MAX, SATURATION_DEFAULT, SATURATION_STEP);
    m_widget->setUpSlider(SLIDER_CONTRAST, CONTRAST_MIN, CONTRAST_MAX, CONTRAST_DEFAULT, CONTRAST_STEP);
    m_widget->setUpSlider(SLIDER_GAMMA, GAMMA_MIN, GAMMA_MAX, GAMMA_DEFAULT, GAMMA_STEP);
    m_widget->setUpSlider(SLIDER_FPS, FPS_MIN, FPS_MAX, FPS_DEFAULT, FPS_STEP);


    emit updataWidgetLab(LABEL_BRIGHTNESS, "Brightness: " + QString::number(BRIGHTNESS_DEFAULT));
    emit updataWidgetLab(LABEL_SATURATION, "Saturation: " + QString::number(SATURATION_DEFAULT));
    emit updataWidgetLab(LABEL_CONTRAST, "Contrast: " + QString::number(CONTRAST_DEFAULT));
    emit updataWidgetLab(LABEL_GAMMA, "Gamma: " + QString::number(GAMMA_DEFAULT));
    emit updataWidgetLab(LABEL_FPS, "FPS: " + QString::number(FPS_DEFAULT));

}

void ViewModel::handleCameraSignals(CameraSignal signal)
{
    switch (signal)
    {
        case DATATREADY:
        auto photo = m_camera->getImage();
        emit(updatePhoto(photo));
        break;
    }
}

void ViewModel::handleWidgetButtonSignals(WidgetSiganl signal)
{
    switch (signal)
    {
        case TAKEPHOTO:
            emit updateUI(HIDEPHOTO);           
            m_camera->capturePhoto(generateTimestampFilename(), PHOTO_DIR);
            m_albManager->upDatePhoto();
            break;
        case EXIT:            
            QApplication::quit();
            break;
        case FILTER:           
            qDebug() << "FILTER signal received - opening filter menu...";
            // 滤镜逻辑
            break;
        case ALBUM:            
            m_widget->hide();
            m_album->show();
            emit updataAlbum(m_albManager->getCurrentPhoto());
            emit updataAlbumNumLab(m_albManager->getIndex(), m_albManager->getAlbumNum());
            break;
        case STOP:
            if(m_isGetFrame == true)
            {
                m_isGetFrame = false;
                m_fpsTimer->stop();
                emit changeWidgetBtn(BTN_STOP, false);
                emit updataWidgetLab(LABEL_CAMERA_STATUS, "Camera: disabel");

            }
            else if(m_isGetFrame == false)
            {
                m_isGetFrame = true;
                setFps(m_fps);
                emit changeWidgetBtn(BTN_STOP, true);
                emit updataWidgetLab(LABEL_CAMERA_STATUS, "Camera: ok");
            }
            break;
        case VIDEO:
            break;
        default:
            qDebug() << "Unknown signal received:" << signal;
            break;
    }
}

void ViewModel::handleWidgetSliderSignals(WidgetSiganl signal, int value)
{
    switch (signal) {
        case SLIDER_BRIGHTNESS:
            emit updataWidgetLab(LABEL_BRIGHTNESS, "Brightness: " + QString::number(value));
            m_camera->setBrightness(value);
            break;
        case SLIDER_CONTRAST:
            emit updataWidgetLab(LABEL_CONTRAST, "Contrast: " + QString::number(value));
            m_camera->setContrast(value);
            break;
        case SLIDER_GAMMA:
            emit updataWidgetLab(LABEL_GAMMA, "Gamma: " + QString::number(value));
            m_camera->setGamma(value);
            break;
        case SLIDER_SATURATION:
            emit updataWidgetLab(LABEL_SATURATION, "Saturation: " + QString::number(value));
            m_camera->setSaturation(value);
            break;
        case SLIDER_FPS:
            emit updataWidgetLab(LABEL_FPS, "FPS: " + QString::number(value));
            if(m_isGetFrame == true)
            {
                setFps(value);
            }
            else
            {
                m_fps = value;
            }
            break;
        case SLIDER_PIXEL:
            break;
        default:
            qDebug() << "Unknown slider signal:" << signal;
            break;
    }
}

void ViewModel::handleAlbumSignals(AlbumSignal signal)
{
    switch (signal)
    {
        case ALBUM_EXIT:
            m_album->hide();
            m_widget->show();
            break;
        case ALBUM_LEFT:
            m_albManager->lastPhoto();
            emit updataAlbum(m_albManager->getCurrentPhoto());
            emit updataAlbumNumLab(m_albManager->getIndex(), m_albManager->getAlbumNum());
            break;
        case ALBUM_RIGHT:
            m_albManager->nextPhoto();
            emit updataAlbum(m_albManager->getCurrentPhoto());
            emit updataAlbumNumLab(m_albManager->getIndex(), m_albManager->getAlbumNum());
            break;
        case ALBUM_DELETE:
            m_albManager->deleteCurrentPhoto();
            emit updataAlbum(m_albManager->getCurrentPhoto());
            emit updataAlbumNumLab(m_albManager->getIndex(), m_albManager->getAlbumNum());
            break;
        default:
            qDebug() << "Unknown signal received:" << signal;
            break;
    }
}

void ViewModel::handleFpsTimer()
{
    m_camera->getFrame();
}


