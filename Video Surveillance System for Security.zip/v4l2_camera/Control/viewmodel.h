#ifndef VIEWMODEL_H
#define VIEWMODEL_H

#include "camera.h"
#include "beep.h"
#include "widget.h"
#include "albummanager.h"
#include "album.h"
#include <QObject>
#include <QTimer>

class ViewModel : public QObject
{
    Q_OBJECT
public:
    explicit ViewModel( Camera* camera, Widget* widget, Album* album, QObject *parent = nullptr);

private:
    void buildConnect();
    void setFps(int fps);
    QString generateTimestampFilename(const QString& prefix = "photo", const QString& extension = "jpg");
    void setUpWidget();

private:
    Camera* m_camera;
    Beep* m_beep;
    Widget* m_widget;
    Album* m_album;
    AlbumManager* m_albManager;
    QTimer* m_fpsTimer;
    int m_fps;
    bool m_isGetFrame = false;

private:
    int m_pendingBrightness;

signals:
    void updatePhoto(QImage photo);
    void updateUI(ViewModelSignal message);
    void updataAlbum(const QString &photo);
    void updataAlbumNumLab(int index, int size);
    void updataWidgetLab(WidgetSiganl message, const QString& str);
    void changeWidgetBtn(ChangeWidgetBtn message, bool status);

private slots:
    void handleCameraSignals(CameraSignal signal);
    void handleWidgetButtonSignals(WidgetSiganl signal);
    void handleWidgetSliderSignals(WidgetSiganl signal, int value);
    void handleAlbumSignals(AlbumSignal signal);
    void handleFpsTimer();
};

#endif // VIEWMODEL_H
